/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import vista.FRM_VentanaPrincipal;


/**
 *
 * @author admin2
 */
public class Controlador_FRM_VentanaPrincipal implements ActionListener {
    
    FRM_VentanaPrincipal frm;
    
    public Controlador_FRM_VentanaPrincipal(FRM_VentanaPrincipal frm)
    {
        frm= new FRM_VentanaPrincipal();
        
    }
    
    public void actionPerformed(ActionEvent e)
    {
        frm= new FRM_VentanaPrincipal();
    }
    
    public void Actionërformed(ActionEvent e)
    {
        if(e.getActionCommand().equals("Salir"))
        {
            System.exit(0);
        }//fin if
        
        if(e.getActionCommand().equals("Registro de Libros"))
        {
            frm.setVisible(true);
            
        }//fin if
    }
    
}
