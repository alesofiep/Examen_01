/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.MetodosBiblioteca;
import vista.FRM_MantenimientoBiblioteca;

/**
 *
 * @author admin2
 */
public class Controlador_FRM_MantenimientoBiblioteca implements ActionListener{
    
    FRM_MantenimientoBiblioteca frm;
    MetodosBiblioteca metodosBiblioteca;
    
    public Controlador_FRM_MantenimientoBiblioteca(FRM_MantenimientoBiblioteca frm)
    {
        frm= new FRM_MantenimientoBiblioteca();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
       if(e.getActionCommand().equals("Agregar"))
        {
            metodosBiblioteca.agregar(frm.devolverInformacion());
            frm.mostrarMensaje("El libro fue registrado de forma correcta");
            frm.resetearGUI();
        }
        if(e.getActionCommand().equals("Consultar")))
        {
            buscarMantenimiento();
        }
        if(e.getActionCommand().equals("Modificar"))
        {
            metodosBiblioteca.modificarMantenimiento(frm.devolverInformacion());
            frm.mostrarMensaje("El libro fue modificado de forma correcta.");
            frm.resetearGUI();     
        }
        if(e.getActionCommand().equals("Eliminar"))
        {
            metodosBiblioteca.eliminarCurso(frm.devolverInformacion());
            frm.mostrarMensaje("El libro fue eliminado de forma correcta.");
            frm.resetearGUI();
        }

    }
    
    
    public void buscarMantenimiento()
    {
        if(metodosBiblioteca.consultarNumeroPrestamo(frm.devolverNumero()))
            {
                frm.mostrarInformacion(metodosBiblioteca.retornarArreglo());
                frm.habilitarEdicion();
            }
            else
            {
                frm.mostrarMensaje("La sigla buscada no se encuentra.");
                frm.habilitarAgregar();
            }
    }
   
    
}
