/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author admin2
 */
public class MetodosBiblioteca {
    
    private ArrayList <Biblioteca> arrayBiblio;
    String infoConsultada[]= new String [3];
    
    public MetodosBiblioteca()
    {
        arrayBiblio= new ArrayList <Biblioteca>();
        
    }
    
    public String devolverNumero()
    {
        String codigo= "0000"+this.arrayBiblio.size()+1;
        codigo=codigo.substring(codigo.length()-5,codigo.length());
        return codigo;
    }
    
    public void agregar(String arreglo[])
    {
        Biblioteca biblio= new Biblioteca(arreglo[0],arreglo[1],arreglo[2],arreglo[3]);
        arrayBiblio.add(biblio);
    }
    
    public void eliminarCurso(String arreglo[])
    {
        for(int i=0; i<arrayBiblio.size(); i++)
        {
            if(arrayBiblio.get(i).getNumeroPrestamo().equals(arreglo[0]))
            {
                arrayBiblio.remove(i);
            }//fin if
        }//fin for
    }//eliminar curso
    
    public boolean consultarNumeroPrestamo(String numeroPrstamo)
    {
        boolean existe=false;
        
        for(int i=0; i<arrayBiblio.size();i++)
        {
            if(arrayBiblio.get(i).getNumeroPrestamo().equals(numeroPrstamo))
            {
                infoConsultada[0]=arrayBiblio.get(i).getNombre();
                infoConsultada[1]=arrayBiblio.get(i).getCedula();
                infoConsultada[2]=arrayBiblio.get(i).getCodigoLibro();
                existe=true;
            }//fin if
        }//fin for
        return existe;
    }
    
    public void modificarMantenimiento(String arreglo[])
    {
        for(int i=0;i<arrayBiblio.size();i++)
        {
            if(arrayBiblio.get(i).getNumeroPrestamo().equals(arreglo[0]))
            {
                arrayBiblio.get(i).setNombre(arreglo[1]);
                arrayBiblio.get(i).setCedula(arreglo[2]);
                arrayBiblio.get(i).setCodigoLibro(arreglo[3]);
            }//fin if
            
        }//fin for
        
    }//fin modificar
    
    public String[] retornarArreglo()
    {
        return this.infoConsultada;
    }
    
}
