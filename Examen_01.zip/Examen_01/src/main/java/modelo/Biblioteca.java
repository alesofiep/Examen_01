/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author admin2
 */
public class Biblioteca {
    
    private String numeroPrestamo;
    private String nombre;
    private String cedula;
    private String codigoLibro;

    public Biblioteca(String numeroPrestamo, String nombre, String cedula, String codigoLibro) {
        this.numeroPrestamo = numeroPrestamo;
        this.nombre = nombre;
        this.cedula = cedula;
        this.codigoLibro = codigoLibro;
    }

    public String getNumeroPrestamo() {
        return numeroPrestamo;
    }

    public void setNumeroPrestamo(String numeroPrestamo) {
        this.numeroPrestamo = numeroPrestamo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getCodigoLibro() {
        return codigoLibro;
    }

    public void setCodigoLibro(String codigoLibro) {
        this.codigoLibro = codigoLibro;
    }
    
    
}//fin de la clase
